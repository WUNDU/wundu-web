const Home = (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg
      width="25"
      height="26"
      viewBox="0 0 30 30"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M2.5 15.255C2.5 12.3938 2.5 10.9637 3.15 9.77875C3.7975 8.5925 4.98375 7.8575 7.355 6.385L9.855 4.83375C12.3612 3.2775 13.615 2.5 15 2.5C16.385 2.5 17.6375 3.2775 20.145 4.83375L22.645 6.385C25.0162 7.8575 26.2025 8.5925 26.8513 9.77875C27.5 10.965 27.5 12.3937 27.5 15.2538V17.1563C27.5 22.0313 27.5 24.47 26.035 25.985C24.57 27.5 22.2137 27.5 17.5 27.5H12.5C7.78625 27.5 5.42875 27.5 3.965 25.985C2.50125 24.47 2.5 22.0325 2.5 17.1563V15.255Z"
        stroke="currentColor"
        strokeOpacity="0.8"
        strokeWidth="2"
      />
      <path
        d="M15 18.75V22.5"
        stroke="currentColor"
        strokeOpacity="0.8"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
};
export default Home;
