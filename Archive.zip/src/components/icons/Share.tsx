import React from "react";

const Share = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={24}
      height={24}
      viewBox="0 0 24 24"
    >
      <path
        fill="currentColor"
        d="M19 14a5 5 0 0 0-3.59 1.53l-5.49-2.75A5 5 0 0 0 10 12a5 5 0 0 0-.08-.78l5.49-2.75A5 5 0 1 0 14 5a5 5 0 0 0 .08.78L8.59 8.53a5 5 0 1 0 0 6.94l5.49 2.75A5 5 0 0 0 14 19a5 5 0 1 0 5-5"
      ></path>
    </svg>
  );
};

export default Share;
