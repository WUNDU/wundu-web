const ImageHome = (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg
      width="22"
      height="22"
      viewBox="0 0 22 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        d="M19.1667 2.83333V19.1667H2.83333V2.83333H19.1667ZM19.1667 0.5H2.83333C1.55 0.5 0.5 1.55 0.5 2.83333V19.1667C0.5 20.45 1.55 21.5 2.83333 21.5H19.1667C20.45 21.5 21.5 20.45 21.5 19.1667V2.83333C21.5 1.55 20.45 0.5 19.1667 0.5ZM13.4967 10.8367L9.99667 15.3517L7.5 12.33L4 16.8333H18L13.4967 10.8367Z"
        fill="currentColor"
      />
    </svg>
  );
};
export default ImageHome;
