const Calendar = (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg
      width="25"
      height="26"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        opacity="0.9"
        d="M14.5 3V1M5.5 3V1M1.25 6H18.75M1 8.044C1 5.929 1 4.871 1.436 4.063C1.83025 3.34231 2.44199 2.7645 3.184 2.412C4.04 2 5.16 2 7.4 2H12.6C14.84 2 15.96 2 16.816 2.412C17.569 2.774 18.18 3.352 18.564 4.062C19 4.872 19 5.93 19 8.045V12.957C19 15.072 19 16.13 18.564 16.938C18.1698 17.6587 17.558 18.2365 16.816 18.589C15.96 19 14.84 19 12.6 19H7.4C5.16 19 4.04 19 3.184 18.588C2.44214 18.2358 1.83041 17.6583 1.436 16.938C1 16.128 1 15.07 1 12.955V8.044Z"
        stroke="#0F2045"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export default Calendar;
