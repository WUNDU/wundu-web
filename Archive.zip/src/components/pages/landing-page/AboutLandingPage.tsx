// src/components/templates/AboutTemplate/index.tsx (Adaptado para usar FeaturesSection no lugar da seção hardcoded de valores)
"use client";
import React, { useEffect } from "react";
import LandingHeader from "@/src/components/organisms/LandingHeader";
import LandingFooter from "@/src/components/organisms/LandingFooter";
import PageHero from "@/src/components/organisms/PageHero";
import TextSection from "@/src/components/molecules/TextSection";
import TechnologySection from "@/src/components/molecules/TechnologySection";
import FeaturesSection from "@/src/components/organisms/FeaturesSection";

// Import ícones para os valores
import { Shield, Zap, Lightbulb, Eye } from "lucide-react";

const AboutLandingPage: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in");
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll(".fade-in-section").forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  // Dados para a seção de valores
  const values = [
    {
      icon: <Shield className="w-10 h-10 text-orange-600" />,
      title: "Segurança",
      description:
        "Os teus dados financeiros são protegidos com os mais altos padrões de segurança.",
    },
    {
      icon: <Zap className="w-10 h-10 text-orange-600" />,
      title: "Simplicidade",
      description:
        "Interface intuitivo que torna a gestão financeira acessível a todos.",
    },
    {
      icon: <Lightbulb className="w-10 h-10 text-orange-600" />,
      title: "Inovação",
      description:
        "Utilizamos tecnologia de ponta para criar soluções financeiras inteligentes.",
    },
    {
      icon: <Eye className="w-10 h-10 text-orange-600" />,
      title: "Transparência",
      description:
        "Comunicação clara sobre como utilizamos os teus dados e como funciona a nossa plataforma.",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <LandingHeader />
      <PageHero
        title="Sobre a WUNDU"
        description="Transformamos a forma como geris as tuas finanças pessoais, criando uma experiência simples, segura e intuitiva."
      />
      <div className="text-center px-4 sm:px-6 lg:px-8 py-12 border-2 mx-2 p-10 my-5 shadow-2xs border-gray-100">
        <TextSection
          title="A nossa missão"
          content="Democratizar o acesso a ferramentas financeiras inteligentes, ajudando cada pessoa a tomar decisões mais informadas sobre o seu dinheiro."
        />

        {/* Seção de Valores - agora reutilizando FeaturesSection com customizações para matching o estilo original */}
        <FeaturesSection
          title="Os Nossos Valores"
          subtitle=""
          features={values}
          gradientFrom="from-blue-100"
          gradientTo="to-yellow-200"
          containerSize="w-20 h-20"
          containerRounded="rounded-3xl"
          cardRounded="rounded-3xl"
          gridCols={4}
          descriptionClass="text-gray-600 leading-relaxed text-lg"
          titleClass="text-2xl font-bold text-gray-900 mb-6"
        />
      </div>
      <div className="border-2 mx-2 p-10 my-5 shadow-2xs border-gray-100">
        <TextSection
          title="A Nossa História"
          content="A WUNDU nasceu da necessidade de simplificar a gestão financeira pessoal. Percebemos que muitas pessoas têm dificuldade em acompanhar os seus gastos e atingir as suas metas financeiras. Criamos uma solução que combina inteligência artificial com design intuitivo, permitindo que qualquer pessoa possa ter controlo total sobre as suas finanças de forma simples e eficaz. Hoje, ajudamos milhares de utilizadores a alcançar a liberdade financeira através de ferramentas inteligentes e educação financeira de qualidade."
        />

        <TechnologySection />
      </div>

      <LandingFooter />
    </div>
  );
};

export default AboutLandingPage;
